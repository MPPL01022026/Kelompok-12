<div align="center">

<img src="assets/banner.svg" alt="Digital Twin UMKM Bakso Goreng Kak Linda - Kelompok 12" width="100%">

<br>

[![Tentang](https://img.shields.io/badge/TENTANG-b32a1a?style=for-the-badge)](#tentang)
[![Tim](https://img.shields.io/badge/TIM-c0392b?style=for-the-badge)](#tim)
[![Tahap](https://img.shields.io/badge/TAHAP-d9822b?style=for-the-badge)](#tahap)
[![Jadwal](https://img.shields.io/badge/JADWAL-e09a1f?style=for-the-badge)](#jadwal)
[![Tahap 2](https://img.shields.io/badge/PROJECT%20PLANNING-a8450f?style=for-the-badge)](#planning)
[![Tahap 3](https://img.shields.io/badge/EXECUTION-8a4510?style=for-the-badge)](#execution)
[![Tahap 4](https://img.shields.io/badge/MONITORING-6e3109?style=for-the-badge)](#monitoring)
[![Dokumen](https://img.shields.io/badge/DOKUMEN-b8680f?style=for-the-badge)](#dokumen)
[![Cara Kerja](https://img.shields.io/badge/CARA%20KERJA-7a3d0c?style=for-the-badge)](#cara-kerja)

![Status](https://img.shields.io/badge/status-tahap%20perencanaan-e09a1f?style=flat-square)
![Kelompok](https://img.shields.io/badge/kelompok-12-c0392b?style=flat-square)
![Prodi](https://img.shields.io/badge/Informatika-Universitas%20Samudra-7a3d0c?style=flat-square)
![Matkul](https://img.shields.io/badge/MPPL-Manajemen%20Proyek%20Perangkat%20Lunak-b8680f?style=flat-square)

**Merencanakan model digital sederhana untuk usaha Kak Linda: pesanan, stok, dan penjualan tahu bakso, tempe, sosis, dan bakso goreng.**

</div>

<img src="assets/divider.svg" width="100%" alt="">

<a id="tentang"></a>
## 🍢 Tentang Proyek

> 🎯 **TUJUAN:** merencanakan digital twin sederhana supaya pesanan di usaha Kak Linda tidak lagi terlupa dan datanya lebih rapi.
> 🧑‍🍳 **TIM:** Kelompok 12, 4 orang.
> 📍 **POSISI SAAT INI:** tahap perencanaan. Dokumen awal, Tahap 2 (jadwal, manday, biaya, risiko), dan Tahap 3 (laporan eksekusi dan prototipe awal) sudah berupa draf. Bukti commit GitHub dan keputusan rapat masih perlu dilengkapi kelompok.

Kak Linda menjual tahu bakso, tempe, sosis, dan bakso goreng. Pesanan masuk secara langsung, pencatatan memakai buku, dan kesulitan yang dirasakan adalah pesanan sering lupa.

Kelompok kami **merencanakan** model digital usaha yang memuat pesanan, stok, dan penjualan. Website pemesanan direncanakan menjadi salah satu jalur masuk pesanan.

| Kondisi | Kebutuhan | Solusi yang direncanakan |
|---|---|---|
| Pesanan masuk langsung, dicatat di buku, pesanan sering lupa | Pesanan, stok, dan penjualan tercatat jelas | Model digital usaha dengan website pemesanan sebagai salah satu jalur pesanan |

<details>
<summary><b>🧺 Produk Kak Linda (klik untuk membuka)</b></summary>

<br>

| Produk | Keterangan |
|---|---|
| Tahu bakso | Dijual saat ini |
| Tempe | Dijual saat ini |
| Sosis | Dijual saat ini |
| Bakso goreng | Dijual saat ini |
| Harga tepat per produk dan data lain | [ISI dari wawancara lanjutan] |

</details>

<img src="assets/divider.svg" width="100%" alt="">

<a id="tim"></a>
## 👥 Tim Kelompok 12

<div align="center">
<img src="assets/team.svg" alt="Kartu anggota: Intan Fadila, Fitri Nabila Suhendra, Chaira Syakira Lubis, Siti Najri Apriyanti" width="100%">
</div>

| No | Nama | NIM | GitHub | Peran utama |
|:-:|---|---|---|---|
| 1 | Intan Fadila | 230504074 | [intanfadila-ui](https://github.com/intanfadila-ui) | Analisis Titik Fungsi |
| 2 | Fitri Nabila Suhendra | 230504056 | [fitrinabila-gif](https://github.com/fitrinabila-gif) | WBS |
| 3 | Chaira Syakira Lubis | 230504064 | [narashaa](https://github.com/narashaa) | Pendaftaran Pemangku Kepentingan |
| 4 | Siti Najri Apriyanti | 230504073 | [stnajriapriyanti-dot](https://github.com/stnajriapriyanti-dot) | Piagam Proyek |

Kelompok bekerja tanpa ketua. Keputusan diambil bersama dalam rapat.  
**Program studi:** Informatika | **Universitas:** Universitas Samudra  
**Mata kuliah:** Manajemen Proyek Perangkat Lunak | **Dosen:** Cut Alna Fadhilla, S.Kom., M.Sc.

<img src="assets/divider.svg" width="100%" alt="">

<a id="tahap"></a>
## 🔥 Tusuk Progres Fase WBS

<div align="center">
<img src="assets/levels.svg" alt="Tusuk progres: tahap 1 dan 2 selesai sebagai draf, tahap 3 berikutnya" width="100%">
</div>

Tusuk ini menunjukkan **tujuh fase pekerjaan di WBS**, bukan tahap tugas kuliah. Status tugas kuliah (Tahap 2 Project Planning dan Tahap 3 Project Execution) ada di bagian Project Planning dan Project Execution di bawah. Klik tiap fase untuk melihat isinya. Kode mengikuti [WBS](docs/04-wbs.md).

<details>
<summary><b>1 · Inisiasi</b> &nbsp; ✅ selesai (draf)</summary>

<br>

- **1.1** Wawancara dan observasi
- **1.2** Latar belakang dan ide
- **1.3** Project Charter
- **1.4** Stakeholder Register

📄 [Latar Belakang dan Ide](docs/01-latar-belakang-dan-ide-proyek.md) · [Project Charter](docs/02-project-charter.md) · [Stakeholder Register](docs/03-stakeholder-register.md)  
🧑‍🍳 Penanggung jawab: Siti Najri Apriyanti, Chaira Syakira Lubis, semua anggota (1.1)

</details>

<details>
<summary><b>2 · Perencanaan</b> &nbsp; ✅ selesai (draf)</summary>

<br>

- **2.1** WBS
- **2.2** Jadwal dan manday
- **2.3** Biaya dan risiko
- **2.4** Persiapan GitHub

📄 [WBS](docs/04-wbs.md) · [Git dan GitHub](docs/05-git-dan-github.md) · [Jadwal Gantt](docs/tahap-2-project-planning/jadwal-gantt.md) · [Manday](docs/tahap-2-project-planning/effort-manday.md) · [Biaya](docs/tahap-2-project-planning/estimasi-biaya.md) · [Risiko](docs/tahap-2-project-planning/risk-register.md)  
🧑‍🍳 Penanggung jawab: Fitri Nabila Suhendra, Chaira Syakira Lubis, semua anggota (2.4)

</details>

<details>
<summary><b>3 · Analisis Kebutuhan</b> &nbsp; 🔥 sedang berjalan (3.1 selesai, 3.2 dan 3.3 belum)</summary>

<br>

- **3.1** Daftar kebutuhan (draf selesai, [Dokumen 06](docs/06-daftar-kebutuhan.md))
- **3.2** Analisis Titik Fungsi
- **3.3** Validasi dengan Kak Linda

🧑‍🍳 Penanggung jawab: Chaira Syakira Lubis, Intan Fadila

</details>

<details>
<summary><b>4 · Perancangan</b> &nbsp; 🔥 sedang berjalan (4.1 dan 4.3 selesai, 4.2 belum)</summary>

<br>

- **4.1** Alur proses usaha (draf selesai, [Dokumen 07](docs/07-alur-proses.md))
- **4.2** Rancangan data
- **4.3** Rancangan tampilan (draf selesai, [Dokumen 08](docs/08-rancangan-tampilan.md))

🧑‍🍳 Penanggung jawab: Fitri Nabila Suhendra, Intan Fadila, Siti Najri Apriyanti

</details>

<details>
<summary><b>5 · Pengembangan</b> &nbsp; 🔒 belum dimulai</summary>

<br>

- **5.1** Pencatatan pesanan
- **5.2** Pencatatan stok
- **5.3** Penjualan dan ringkasan
- **5.4** Website pemesanan

🧑‍🍳 Penanggung jawab: Intan Fadila, Fitri Nabila Suhendra, Chaira Syakira Lubis, Siti Najri Apriyanti

</details>

<details>
<summary><b>6 · Pengujian</b> &nbsp; 🔒 belum dimulai</summary>

<br>

- **6.1** Rencana uji
- **6.2** Pelaksanaan uji
- **6.3** Uji dengan Kak Linda
- **6.4** Perbaikan

🧑‍🍳 Penanggung jawab: Fitri Nabila Suhendra, Chaira Syakira Lubis, Intan Fadila, semua anggota (6.2)

</details>

<details>
<summary><b>7 · Dokumentasi</b> &nbsp; 🔒 belum dimulai</summary>

<br>

- **7.1** Panduan pengguna
- **7.2** Laporan akhir
- **7.3** Bahan presentasi
- **7.4** Arsip repositori

🧑‍🍳 Penanggung jawab: Siti Najri Apriyanti, Fitri Nabila Suhendra, Chaira Syakira Lubis, Intan Fadila

</details>

<img src="assets/divider.svg" width="100%" alt="">

<a id="jadwal"></a>
## 📅 Jadwal

| Tonggak | Tenggat | Pekerjaan terakhir selesai (rencana) | Status |
|---|---|---|---|
| MS1 · Tahap 2 Project Planning | 24 Oktober 2026 | 15 Oktober 2026 | Draf selesai |
| MS2 · Tahap 3 Project Execution | 10 November 2026 | 4 November 2026 | Laporan disusun |
| MS3 · Pengembangan dan pengujian selesai (target) | 27 November 2026 | 26 November 2026 | Belum dimulai |
| MS4 · Tahap 4 dan 5 dikumpulkan | 1 Desember 2026 | 30 November 2026 | Belum dimulai |

> Tenggat adalah tenggat resmi dari dosen. Tanggal mulai (30 September 2026, hari wawancara pertama) adalah asumsi. Cadangan waktu menuju 1 Desember tinggal 1 hari kerja.

<img src="assets/divider.svg" width="100%" alt="">

<a id="planning"></a>
## 📊 Project Planning (Tahap 2)

| Keluaran | Berkas |
|---|---|
| Jadwal dan Gantt Chart | [jadwal-gantt.md](docs/tahap-2-project-planning/jadwal-gantt.md) |
| Resource dan Responsibility Plan | [resource-plan.md](docs/tahap-2-project-planning/resource-plan.md) |
| Estimasi Usaha (Manday, PERT) | [effort-manday.md](docs/tahap-2-project-planning/effort-manday.md) |
| Estimasi Biaya | [estimasi-biaya.md](docs/tahap-2-project-planning/estimasi-biaya.md) |
| Risk Register | [risk-register.md](docs/tahap-2-project-planning/risk-register.md) |
| Excel lengkap (rumus hidup) | [Tahap2_Project_Planning_Bakso_Kak_Linda.xlsx](docs/tahap-2-project-planning/Tahap2_Project_Planning_Bakso_Kak_Linda.xlsx) |
| Halaman interaktif | [index.html](index.html) (aktifkan GitHub Pages: Settings > Pages > Branch main, folder root) |

Ringkasan: 26 aktivitas, 83,7 manday, tanggal selesai 11 Desember 2026, biaya tunai Rp 643.500, total termasuk nilai setara tenaga kerja Rp 8.419.125, 2 risiko Tinggi.

<img src="assets/divider.svg" width="100%" alt="">

<a id="execution"></a>
## ⚙️ Project Execution (Tahap 3)

| Keluaran | Berkas |
|---|---|
| Laporan Project Execution (pembagian tugas, progres, catatan rapat, bukti GitHub) | [laporan-project-execution.md](docs/tahap-3-project-execution/laporan-project-execution.md) |
| Prototipe awal v0.1 | [catat-pesanan.html](prototipe/catat-pesanan.html) |

Ringkasan: 10 aktivitas terbukti selesai (draf) atau 27,5% dari 83,7 manday, rencana per 31 Oktober 2026 adalah 40,0%. Aktivitas 3.2 dan 3.3 tertinggal.

<img src="assets/divider.svg" width="100%" alt="">

<a id="monitoring"></a>
## 📈 Monitoring dan Controlling (Tahap 4)

| Keluaran | Berkas |
|---|---|
| Laporan (waktu, manday, biaya, masalah, perubahan lingkup, tindakan korektif) | [laporan-monitoring-controlling.md](docs/tahap-4-monitoring-controlling/laporan-monitoring-controlling.md) |
| Berkas hitung (selisih otomatis) | [Tahap4_Monitoring_Controlling.xlsx](docs/tahap-4-monitoring-controlling/Tahap4_Monitoring_Controlling.xlsx) |

Baseline diambil dari Excel Tahap 2. Data aktual diisi dari kejadian nyata. Temuan sementara: aktivitas 3.1, 4.1, dan 4.3 selesai 31 Oktober 2026, lebih lambat 8, 5, dan 4 hari kerja dari rencana.

<img src="assets/divider.svg" width="100%" alt="">

<a id="dokumen"></a>
## 📄 Dokumen

| No | Dokumen | Isi | Penanggung jawab | Status |
|:-:|---|---|---|---|
| 1 | [Latar Belakang dan Ide Proyek](docs/01-latar-belakang-dan-ide-proyek.md) | Latar belakang, wawancara, masalah, alternatif ide, tujuan | Siti Najri Apriyanti | Draf |
| 2 | [Project Charter](docs/02-project-charter.md) | Piagam proyek, risiko awal, tonggak | Siti Najri Apriyanti | Draf |
| 3 | [Stakeholder Register](docs/03-stakeholder-register.md) | Pemangku kepentingan, matriks, rencana komunikasi | Chaira Syakira Lubis | Draf |
| 4 | [WBS](docs/04-wbs.md) | Rincian pekerjaan dan pembagian tugas | Fitri Nabila Suhendra | Draf |
| 5 | [Git dan GitHub](docs/05-git-dan-github.md) | Istilah, perintah, alur kerja, cara unggah | Semua anggota | Draf |
| 6 | [Project Planning (Tahap 2)](docs/tahap-2-project-planning/jadwal-gantt.md) | Jadwal, resource, manday, biaya, risiko | Semua anggota | Draf |
| 7 | [Daftar Kebutuhan](docs/06-daftar-kebutuhan.md) | Kebutuhan fungsional dan nonfungsional | Chaira Syakira Lubis | Draf |
| 8 | [Alur Proses](docs/07-alur-proses.md) | Alur sekarang dan yang direncanakan | Fitri Nabila Suhendra | Draf |
| 9 | [Rancangan Tampilan](docs/08-rancangan-tampilan.md) | Pilihan bentuk dan rancangan layar | Siti Najri Apriyanti | Draf |
| 10 | Analisis Titik Fungsi | Ukuran pekerjaan | Intan Fadila | Belum dimulai |

<details>
<summary><b>📁 Isi repositori</b></summary>

```text
.
├── README.md
├── assets/
│   ├── banner.svg
│   ├── divider.svg
│   ├── team.svg
│   └── levels.svg
├── index.html
├── prototipe/
│   └── catat-pesanan.html
└── docs/
    ├── 01-latar-belakang-dan-ide-proyek.md
    ├── 02-project-charter.md
    ├── 03-stakeholder-register.md
    ├── 04-wbs.md
    ├── 05-git-dan-github.md
    ├── 06-daftar-kebutuhan.md
    ├── 07-alur-proses.md
    ├── 08-rancangan-tampilan.md
    ├── tahap-4-monitoring-controlling/
    │   ├── laporan-monitoring-controlling.md
    │   └── Tahap4_Monitoring_Controlling.xlsx
    ├── tahap-3-project-execution/
    │   └── laporan-project-execution.md
    └── tahap-2-project-planning/
        ├── jadwal-gantt.md
        ├── resource-plan.md
        ├── effort-manday.md
        ├── estimasi-biaya.md
        ├── risk-register.md
        └── Tahap2_Project_Planning_Bakso_Kak_Linda.xlsx
```

</details>

<img src="assets/divider.svg" width="100%" alt="">

<a id="cara-kerja"></a>
## 🤝 Cara Kerja Tim

1. Ambil pembaruan terbaru: `git pull origin main`.
2. Buat branch per tugas, contoh `wbs-fitri`.
3. Commit dengan pesan jelas, lalu `git push`.
4. Buka Pull Request, minta satu anggota lain memeriksa.
5. Catat tugas di Issues dengan kode WBS, contoh `[2.1] Susun WBS`.

Aturan lengkap ada di [Git dan GitHub](docs/05-git-dan-github.md).

<div align="center"><sub>Kelompok 12 • Informatika • Universitas Samudra</sub></div>
